// LUMEN EDU — shared interactions
document.addEventListener('DOMContentLoaded', () => {

  // sticky nav background swap after hero
  const nav = document.querySelector('.site-nav');
  const flipPoint = 90;
  const onScroll = () => {
    if (window.scrollY > flipPoint) document.body.classList.add('light-nav');
    else document.body.classList.remove('light-nav');
  };
  onScroll();
  window.addEventListener('scroll', onScroll, { passive: true });

  // mobile nav toggle
  const burger = document.querySelector('.nav-burger');
  const links = document.querySelector('.nav-links');
  if (burger && links) {
    burger.addEventListener('click', () => {
      burger.classList.toggle('open');
      links.classList.toggle('open');
    });
    links.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
      burger.classList.remove('open');
      links.classList.remove('open');
    }));
  }

  // scroll reveal
  const revealEls = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if (e.isIntersecting) {
          e.target.classList.add('in');
          io.unobserve(e.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
    revealEls.forEach(el => io.observe(el));
  } else {
    revealEls.forEach(el => el.classList.add('in'));
  }

  // faq accordion
  document.querySelectorAll('.faq-item').forEach(item => {
    const q = item.querySelector('.faq-q');
    const a = item.querySelector('.faq-a');
    q.addEventListener('click', () => {
      const isOpen = item.classList.contains('open');
      item.closest('.faq').querySelectorAll('.faq-item').forEach(other => {
        other.classList.remove('open');
        other.querySelector('.faq-a').style.maxHeight = null;
      });
      if (!isOpen) {
        item.classList.add('open');
        a.style.maxHeight = a.scrollHeight + 'px';
      }
    });
  });

  // consultation form -> sends data to a Cloudflare Worker, which
  // forwards it to Lumen Edu's Telegram bot. The bot token is NOT stored
  // here — it lives only as a secret inside the Worker.
  // Replace the URL below with your deployed Worker's URL,
  // e.g. https://lumen-edu-form.your-subdomain.workers.dev
  const WORKER_URL = 'https://lumen-edu-form.lokshina0222.workers.dev/';

  const consultForm = document.getElementById('consultForm');
  if (consultForm) {
    const status = document.getElementById('formStatus');
    consultForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const btn = consultForm.querySelector('button[type="submit"]');
      const originalLabel = btn.textContent;

      const name = consultForm.querySelector('#name').value.trim();
      const phone = consultForm.querySelector('#phone').value.trim();
      const email = consultForm.querySelector('#email').value.trim();
      const country = consultForm.querySelector('#country').value;

      btn.disabled = true;
      btn.textContent = 'Надсилаємо…';
      status.textContent = '';

      try {
        const res = await fetch(WORKER_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name, phone, email, country })
        });
        const result = await res.json();
        if (!res.ok || !result.ok) throw new Error(result.error || 'Request failed');

        consultForm.reset();
        status.textContent = 'Дякуємо! Заявку надіслано, ми зв\'яжемось із вами найближчим часом.';
        status.style.color = 'var(--gold-bright)';
      } catch (err) {
        console.error(err);
        status.textContent = 'Не вдалося надіслати. Напишіть нам напряму в Telegram: @lumen_edu_bot';
        status.style.color = '#e08a7a';
      } finally {
        btn.disabled = false;
        btn.textContent = originalLabel;
      }
    });
  }

  // language toggle (UA active; EN shows a gentle notice for now)
  document.querySelectorAll('.lang-toggle').forEach(group => {
    group.querySelectorAll('button').forEach(btn => {
      btn.addEventListener('click', () => {
        if (btn.dataset.lang === 'en') {
          alert('English version is on the way — for now, the Ukrainian site is complete and live.');
          return;
        }
        group.querySelectorAll('button').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
      });
    });
  });
});
